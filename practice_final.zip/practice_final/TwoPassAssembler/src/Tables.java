import java.util.ArrayList;

public class Tables {
	ArrayList<TablesParameters> symbolTable = new ArrayList<TablesParameters>();
	ArrayList<String> symbolTableToken = new ArrayList<String>();
	ArrayList symbolTableAddress = new ArrayList();
	ArrayList<TablesParameters> literalTable = new ArrayList<TablesParameters>();
	ArrayList<String> literalTableToken = new ArrayList<String>();
	ArrayList literalTableAddress = new ArrayList();
	ArrayList<String> poolTable = new ArrayList<String>();
	
}
