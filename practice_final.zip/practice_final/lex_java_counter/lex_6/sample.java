import java.util.*;

class Hello 
{
	public static void main(String [] args) 
	{
		int a,b,c;
		int x=1,y=3;
		c=a+b;
		System.out.println("Addition is:"+c);
	}
}

