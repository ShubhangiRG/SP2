#define NOUN 257
#define VERB 258
#define PRONOUN 259
#define CONJUNCTION 260
#define FULLSTOP 261
